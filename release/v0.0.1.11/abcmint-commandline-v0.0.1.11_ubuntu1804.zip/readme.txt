view help: ./abcmint-commandline-v0.0.1.11_ubuntu1804 --help
Run program: ./abcmint-commandline-v0.0.1.11_ubuntu1804 &(When running for the first time, because there is no configuration file, you will be prompted how to configure it. You can create the configuration file according to the prompt and run it again)

RPC Description:
help [command]: Through this interface, you can view the following interface description，[command] is the following interface name.
addnode <node> <add|remove|onetry>
createrawtransaction [{"txid":txid,"vout":n},...] {address:amount,...}
decoderawtransaction <hex string>
dumpkey <abcmintaddress>：Export public and private keys
encryptwallet <passphrase>
getaccount <abcmintaddress>：Get account by address
getaddednodeinfo <dns> [node]
getaddressesbyaccount <account>：Get address by account
newgetbalance [address]：Obtain the available balance, unconfirmed balance, immature balance according to the address, and obtain the balance of the entire wallet without filling in the address
getblock <hash>
getblockcount
getblockhash <index>
getblocktemplate
getchoisedconfigvalue：Query the description of the security key that can be generated
getconnectioncount
getdifficulty
getgenerate：Query whether the current mining is in progress
getinfo
getmininginfo
getnewaddress <config_value>[account]：Create a new address，config_value: valid values can be queried through the getchoisedconfigvalue interface，also fill in 0，non-secure (UOV_SL0.8) key will be generated.
getpeerinfo
getpublickeypos <address>：Get the location corresponding to the public key according to the address
getrawmempool
getrawtransaction <txid> [verbose=0]
getreceivedbyaccount <account> [minconf=1]
getreceivedbyaddress <abcmintaddress> [minconf=1]
gettransaction <txid>
gettxout <txid> <n> [includemempool=true]
gettxoutsetinfo
getwork [data]
importkey <abcmintkey> [label] [rescan=true]：Import public and private keys
newlistaccounts：Get the available balance of all accounts
listaddressgroupings
listlockunspent
listreceivedbyaccount [minconf=1] [includeempty=false]
listreceivedbyaddress [minconf=1] [includeempty=false]
listsinceblock [blockhash] [target-confirmations]
listtransactions [account] [count=10] [from=0]
listunspent [minconf=1] [maxconf=9999999] ["address",...]
lockunspent unlock? [array-of-Objects]
move <fromaccount> <toaccount> <amount> [minconf=1] [comment]
sendfrom <fromaccount> <toabcmintaddress> <amount> [minconf=1] [comment] [comment-to]
sendmany <fromaccount> {address:amount,...} [minconf=1] [comment]
sendrawtransaction <hex string>
sendtoaddress <abcmintaddress> <amount> [comment] [comment-to]
setaccount <abcmintaddress> <account>：Set the account name corresponding to the address
setgenerate <generate> [genproclimit]：Start or stop mining. True is  start mining, false is  stop mining
settxfee <amount>
signmessage <abcmintaddress> <message>
signrawtransaction <hex string>
submitblock <hex data> [optional-params-obj]
validateaddress <abcmintaddress>
verifymessage <abcmintaddress> <signature> <message>

Backup wallet:
Save the wallet.dat, which is in the datadir directory. datadir is specified by the -datadir parameter when the program is running. If not specified, the default path is "/home/username/.abc/". Please verify the availability of the backup wallet by yourself to prevent the backup wallet data from being unavailable due to errors.


